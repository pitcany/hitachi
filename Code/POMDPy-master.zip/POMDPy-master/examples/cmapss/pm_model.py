from __future__ import print_function
from __future__ import absolute_import
from __future__ import division
from past.utils import old_div
from builtins import str
from builtins import map
from builtins import hex
from builtins import range
from past.utils import old_div
import logging
import json
import numpy as np
from pomdpy.util import console, config_parser
from .pm_state import PMState
from .pm_action import *
from .pm_observation import PMObservation
from .pm_data import PMData
from pomdpy.discrete_pomdp import DiscreteActionPool, DiscreteObservationPool
from pomdpy.pomdp import Model, StepResult
import pandas as pd
from sklearn import preprocessing
from scipy.stats import norm
from pomdpy.pomdp import model

module = "PMModel"

class PMModel(model.Model):
    def __init__(self, args):
        print('creating predictive maintanence model')
        super(PMModel, self).__init__(args)
        print('args', args)
        self.Allobservations = self.get_observations(args['data_dir'])
        self.cur_idx = 0
        self.cycle_idx = 0
        self.observations = PMObservation(self.Allobservations[self.cycle_idx][self.cur_idx])
        self.total_cycles = len(self.Allobservations)
        self.end_idx = len(self.Allobservations[self.cycle_idx])-1
        print('Obtained observations:', self.observations.observations.shape,'for predictive maintanence')
        self.num_states = 4
        self.num_actions = 2
        self.num_observations = 13 # Dataframe column size
        self.current_state = [False, 0]

    def start_scenario(self):
        self.cur_idx = 0
        self.cycle_idx = 0
        self.observations = PMObservation(elf.Allobservations[self.cycle_idx][self.cur_idx])
        self.total_cycles = len(self.Allobservations)
        self.end_idx = len(self.Allobservations[self.cycle_idx])-1

    def is_terminal(self, state):
        if state.did_fail:
            return True
        else:
            return False

    def normalize(self, data):
        x = data.values
        min_max_scaler = preprocessing.MinMaxScaler()
        x_scaled = min_max_scaler.fit_transform(x)
        dataNew = pd.DataFrame(x_scaled)
        return dataNew

    def get_observations(self, dataPath):
        data = pd.read_csv(dataPath, sep=" ", header=None)
        unique_unit_values = data[0].unique() #Number of units
        data_cycles = []
        for unit_num in unique_unit_values:
            data_cycles.append(data.loc[data[0] == unit_num])
        dataT = data[data.columns[5:26]]
        dataT.columns = range(21)
        dataT.drop(data.columns[[0, 3, 4, 5, 9, 15, 17, 18]],axis=1,inplace=True)
        dataT.columns = range(13)
        dataT = self.normalize(dataT)
        dataT_cycles = []
        for unit_num in unique_unit_values:
            dataT_cycles.append(dataT.loc[data[0] == unit_num].values)
        return dataT_cycles


    def sample_an_init_state(self):
        return self.sample_state_uninformed()

    def create_observation_pool(self, solver):
        return DiscreteObservationPool(solver)

    def sample_state_uninformed(self):
        return PMState(False, 0)

    def sample_state_informed(self, belief): # TODO
        """

        :param belief:
        :return:
        """
        return np.array([0.25,0.25,0.25,0.25])

    def get_all_states(self):
        """
        Did part fail + current condition of the part.
        :return:
        """
        return np.array([[False, 0], [False, 1], [False, 2], [True, 3]])

    def get_all_actions(self):
        """
        Two unique actions
        :return:
        """
        return [PMAction(ActionType.NO_REPAIR), PMAction(ActionType.REPAIR)]

    def get_all_observations(self):
        """
        Returning the mean for all the 3 observations
        :return:
        """
        return np.array([0.3]*13)

    def get_legal_actions(self, _):
        return self.get_all_actions()

    def is_valid(self, _):
        return True

    def reset_for_simulation(self): # TO BE CHANGED
        self.start_scenario()

    # Reset every "episode"
    def reset_for_epoch(self):
        self.start_scenario()

    def update(self, step_result):
        pass

    def get_max_undiscounted_return(self):
        return 10

    @staticmethod
    def get_transition_matrix():
        """
        |A| x |S| x |S'| matrix, for predictive maintanence problem this is 2 x 4 x 4
        :return:
        """
        return np.array([[[0.59531845, 0.40468155, 0.        , 0.        ],
        [0.        , 0.67940393, 0.32059607, 0.        ],
        [0.        , 0.        , 0.93189447, 0.06810553],
        [0.        , 0.        , 0.        , 1.        ]],

       [[0.59531845, 0.40468155, 0.        , 0.        ],
        [0.        , 0.67940393, 0.32059607, 0.        ],
        [0.        , 0.        , 0.93189447, 0.06810553],
        [0.        , 0.        , 0.        , 1.        ]]])

    @staticmethod
    def get_observation_matrix():
        '''
        Maybe not required for our use case
        '''
        """
        |A| x |S| x |O| matrix
        :return:
        """
        return np.array([
            [[0.37283055,0.374906,0.3242897,0.38668906,0.39399698,0.37958637,
            0.31853375,0.38472564,0.39131688,0.37227084,0.37442537,0.33405099,
            0.32759148],
            [0.36329403,0.36581336,0.33566856,0.38305993,0.39214704,0.3697183,
            0.33526748,0.38054837,0.38965391,0.36190718,0.36543005,0.34443547,
            0.34097494],
            [0.34677056,0.35150639,0.35609586,0.37474014,0.38834335,0.34907632,
            0.35505182,0.37197329,0.38622128,0.34437049,0.35044088,0.36228884,
            0.35921203],
            [0.31776182,0.32865963,0.37762648,0.35995349,0.38071166,0.31441088,
            0.37949536,0.35752871,0.37960194,0.31517665,0.326588,0.38100736,
            0.3804138]],
            [[0.37283055,0.374906,0.3242897,0.38668906,0.39399698,0.37958637,
            0.31853375,0.38472564,0.39131688,0.37227084,0.37442537,0.33405099,
            0.32759148],
            [0.36329403,0.36581336,0.33566856,0.38305993,0.39214704,0.3697183,
            0.33526748,0.38054837,0.38965391,0.36190718,0.36543005,0.34443547,
            0.34097494],
            [0.34677056,0.35150639,0.35609586,0.37474014,0.38834335,0.34907632,
            0.35505182,0.37197329,0.38622128,0.34437049,0.35044088,0.36228884,
            0.35921203],
            [0.31776182,0.32865963,0.37762648,0.35995349,0.38071166,0.31441088,
            0.37949536,0.35752871,0.37960194,0.31517665,0.326588,0.38100736,
            0.3804138]]]
        )

    @staticmethod
    def get_reward_matrix():
        """
        |A| x |S| matrix
        :return:
        """
        return np.array([
            [100, 50., 0, -50],     # Taking no repair action for different part conditions
            [-50.0, 0.0, 50, 100],  # Taking repair action for different part conditions
        ])

    @staticmethod
    def get_initial_belief_state():
        return np.array([1.0, 0.0, 0.0, 0.0])

    ''' Factory methods '''

    def create_action_pool(self):
        return DiscreteActionPool(self)

    def create_root_historical_data(self, agent):
        return PMData(self)

    ''' --------- BLACK BOX GENERATION --------- '''

    def generate_step(self, action, state=None):
        if action is None:
            print("ERROR: Tried to generate a step with a null action")
            return None
        elif not isinstance(action, PMAction):
            action = PMAction(action)

        result = model.StepResult()
        result.next_state = self.make_next_state(action)
        result.is_terminal = self.find_is_terminal(action)
        result.action = action.copy()
        result.observation = self.make_observation(action)
        is_cycle_terminal = self.find_is_cycle_terminal(action)
        result.reward = self.make_reward(action, result.next_state, is_cycle_terminal)

        return result

    def make_next_state(self, action):
        # Check if next observation is terminal and then decide.
        if action.bin_number == ActionType.NO_REPAIR:
            probability_correct = np.random.uniform(0, 1)
            if probability_correct >= 0.5:
                return [False, self.current_state[1]]
            else:
                if self.current_state[1] == 3:
                    return self.current_state 
                if self.current_state[1] == 2:
                    return [True, self.current_state[1]+1]
                return [False, self.current_state[1]+1]
        else:
            return [False,0]

    def find_is_terminal(self, action):
        # Check if next observation is terminal and then decide.
        if action.bin_number == ActionType.NO_REPAIR:
            if self.cur_idx == self.end_idx and self.cycle_idx == self.total_cycles - 1:
                return  True# Check if my current observation has reached the end of all possible observations
        return False

    def find_is_cycle_terminal(self,action):
        if action.bin_number == ActionType.NO_REPAIR:
            return self.cur_idx == self.end_idx
        return False

    def make_reward(self, action, next_state, is_cycle_terminal):
        """
        :param action:
        :param is_terminal:
        :return: reward
        """
        if is_cycle_terminal:
            return -150 #Extra bad reward because the cycle has already ended
        rewardMatrix = self.get_reward_matrix()
        return rewardMatrix[action.bin_number][next_state[1]]
        

    def make_observation(self, action):
        """
        :param action:
        :return:
        """
        if action.bin_number == ActionType.REPAIR:
            # Go back to the first observation
            self.cur_idx = 0
            if self.cycle_idx == self.total_cycles - 1:
                self.cycle_idx = 0
            else:
                self.cycle_idx = self.cycle_idx + 1
            self.end_idx = len(self.Allobservations[self.cycle_idx]) - 1
        else:
            if self.cur_idx == self.end_idx:
                self.cur_idx = self.cur_idx
            else:
                self.cur_idx += 1

        return PMObservation(self.Allobservations[self.cycle_idx][self.cur_idx])


    def belief_update(self, old_belief, action, observation):
        """
        Belief is a 2-element array, with element in pos 0 signifying probability that the tiger is behind door 1

        :param old_belief:
        :param action:
        :param observation:
        :return:
        """
        if action == 1:
            return np.array([1.0, 0.0, 0.0, 0.0])
        b_new_nonnormalized = []
        L = len(self.get_all_states())
        Z = self.get_observation_matrix()
        T = self.get_transition_matrix()
        for s_prime in range(L):
            p_o_prime = np.matmul(Z[action][s_prime],observation.observations)
            summation = 0.0
            for s in range(L):
                p_s_prime = T[action][s][s_prime]
                b_s = float(old_belief[s])
                summation = summation + p_s_prime * b_s
            b_new_nonnormalized.append(p_o_prime * summation)

        # normalize
        b_new = []
        total = sum(b_new_nonnormalized)
        for b_s in b_new_nonnormalized:
            b_new.append([b_s/total])
        return np.array(b_new)